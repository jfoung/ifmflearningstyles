import { useState } from "react";
import { ChevronLeft, ChevronRight, Eye, Headphones, BookOpen, Zap, Layers, Monitor, Users, BookMarked, MessageSquare } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const TEAL = "#036255";
const BLUE = "#2b9ed4";
const GREEN = "#49a762";
const LIGHT_BLUE = "#e0edf7";

interface Slide {
  id: number;
  type: "title" | "intro" | "learner" | "strategies" | "closing";
  title?: string;
  subtitle?: string;
  body?: string;
  icon?: React.ReactNode;
  accentColor?: string;
  items?: { label: string; text: string }[];
}

const slides: Slide[] = [
  {
    id: 1,
    type: "title",
    title: "Understanding Your Learning Style",
    subtitle: "Intro Module · Medical Fellowship Program",
    accentColor: TEAL,
  },
  {
    id: 2,
    type: "intro",
    title: "Four Primary Adult Learning Styles",
    body: "Now that you know your learning style better, let's explore the four primary adult learning styles: visual, auditory, reading/writing, and kinesthetic. Each style has distinct characteristics and strategies that can help you adapt to a hybrid educational format.",
    accentColor: BLUE,
  },
  {
    id: 3,
    type: "learner",
    title: "Visual Learners",
    icon: <Eye size={36} strokeWidth={1.5} />,
    accentColor: BLUE,
    body: "You know that this is your style if you prefer to use images, diagrams, charts, and other visual aids to understand and remember information. You benefit from seeing the material rather than just hearing it. Visual learners can adapt to a hybrid program emphasizing learning via video lectures, infographics, and visually rich online content. During in-person sessions, use diagrams and take visual notes to reinforce learning. Mind maps and concept charts can also help organize and recall information effectively.",
  },
  {
    id: 4,
    type: "learner",
    title: "Auditory Learners",
    icon: <Headphones size={36} strokeWidth={1.5} />,
    accentColor: GREEN,
    body: "Do you retain information better when the information is presented through spoken words, such as lectures, discussions, or audio recordings? In a hybrid program, you can maximize your learning by participating in webinars, listening to podcasts, and engaging in group discussions during your monthly small groups and in-person retreats. Recording lectures and discussions for later review can also be beneficial. Additionally, forming a small study group to discuss and review material can help reinforce learning.",
  },
  {
    id: 5,
    type: "learner",
    title: "Reading/Writing Learners",
    icon: <BookOpen size={36} strokeWidth={1.5} />,
    accentColor: TEAL,
    body: "This is your style if you prefer to interact with textual information. You learn best through reading and writing activities, such as taking notes, reading articles, writing in a journal, or creating short essays. To adapt to a hybrid program, you can engage deeply with the assigned reading materials and online text-based resources, such as e-books, articles, and written lectures. During in-person sessions, taking detailed notes and summarizing key points in writing can enhance retention. Creating written summaries and outlines of the material can also aid in understanding and memory.",
  },
  {
    id: 6,
    type: "learner",
    title: "Kinesthetic Learners",
    icon: <Zap size={36} strokeWidth={1.5} />,
    accentColor: GREEN,
    body: "You thrive with hands-on experiences and learning by doing. In a hybrid program, you will benefit from leaning in on those exercises that require you to apply what you learn in your personal and professional life. Use all interactive online tools and engage in activities that require action, like virtual labs or practical exercises. Incorporating movement into your study routine, such as walking while listening to a podcast, can also help.",
  },
  {
    id: 7,
    type: "strategies",
    title: "Adapting to a Hybrid Program",
    subtitle: "To accommodate these diverse learning styles in a hybrid program, you can take a few additional steps:",
    accentColor: BLUE,
    items: [
      {
        label: "Blended Approach",
        text: "While leveraging your preferred learning style is important, try to incorporate elements of other styles. This blended approach can enhance overall learning and adaptability, as various types of information may best be understood through multiple methods.",
      },
      {
        label: "Utilize Technology",
        text: "Modern technology offers numerous tools and resources that cater to various learning styles. You can use apps for visual notetaking, podcasts or audiobooks for auditory learning, simulated activities for kinesthetic practice, and discussion boards to facilitate reading/writing learning through written exchanges.",
      },
    ],
  },
  {
    id: 8,
    type: "strategies",
    title: "Additional Strategies",
    accentColor: TEAL,
    items: [
      {
        label: "Active Participation",
        text: "Engaging actively in both online and in-person components is crucial. This means actively participating in discussions, asking questions, and seeking real-time clarification during live sessions. You can also create study groups with peers to enhance collaborative learning.",
      },
      {
        label: "Regular Reflection",
        text: "Regular reflection on your learning process and outcomes is essential. Keeping a learning journal can help you track progress, identify improvement areas, and adjust strategies.",
      },
      {
        label: "Seek Feedback",
        text: "Obtaining feedback from mentors and peers can provide valuable insights. Please be open to constructive criticism and willing to adjust your approach based on feedback.",
      },
    ],
  },
  {
    id: 9,
    type: "closing",
    title: "Your Learning Journey",
    body: "Understanding your learning style and implementing effective strategies can maximize your learning experience in a hybrid Fellowship program, ensuring a comprehensive and enriching educational journey.",
    accentColor: TEAL,
  },
];

const strategyIcons: Record<string, React.ReactNode> = {
  "Blended Approach": <Layers size={20} strokeWidth={1.5} />,
  "Utilize Technology": <Monitor size={20} strokeWidth={1.5} />,
  "Active Participation": <Users size={20} strokeWidth={1.5} />,
  "Regular Reflection": <BookMarked size={20} strokeWidth={1.5} />,
  "Seek Feedback": <MessageSquare size={20} strokeWidth={1.5} />,
};

export default function App() {
  const [current, setCurrent] = useState(0);
  const [direction, setDirection] = useState(1);

  const go = (next: number) => {
    if (next < 0 || next >= slides.length) return;
    setDirection(next > current ? 1 : -1);
    setCurrent(next);
  };

  const slide = slides[current];

  const variants = {
    enter: (d: number) => ({ x: d > 0 ? 80 : -80, opacity: 0 }),
    center: { x: 0, opacity: 1 },
    exit: (d: number) => ({ x: d > 0 ? -80 : 80, opacity: 0 }),
  };

  return (
    <div
      className="size-full flex flex-col items-center justify-center p-4 sm:p-8"
      style={{ background: LIGHT_BLUE, fontFamily: "'Nunito', sans-serif" }}
    >
      {/* Slide card */}
      <div
        className="w-full max-w-4xl relative overflow-hidden"
        style={{
          background: "#ffffff",
          borderRadius: "1.5rem",
          boxShadow: "0 8px 48px rgba(3,98,85,0.10), 0 2px 12px rgba(43,158,212,0.08)",
          minHeight: "520px",
          display: "flex",
          flexDirection: "column",
        }}
      >
        {/* Top accent bar */}
        <div
          style={{
            height: "5px",
            background: `linear-gradient(90deg, ${TEAL}, ${BLUE}, ${GREEN})`,
            borderRadius: "1.5rem 1.5rem 0 0",
            flexShrink: 0,
          }}
        />

        {/* Slide content */}
        <div className="flex-1 relative overflow-hidden">
          <AnimatePresence custom={direction} mode="wait">
            <motion.div
              key={slide.id}
              custom={direction}
              variants={variants}
              initial="enter"
              animate="center"
              exit="exit"
              transition={{ duration: 0.32, ease: [0.4, 0, 0.2, 1] }}
              className="absolute inset-0 flex flex-col"
              style={{ padding: "2.5rem 3rem" }}
            >
              <SlideContent slide={slide} />
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Bottom navigation */}
        <div
          className="flex items-center justify-between px-8 py-4"
          style={{
            borderTop: `1px solid rgba(3,98,85,0.10)`,
            background: "#fafcfe",
            borderRadius: "0 0 1.5rem 1.5rem",
            flexShrink: 0,
          }}
        >
          <button
            onClick={() => go(current - 1)}
            disabled={current === 0}
            className="flex items-center gap-1 px-4 py-2 rounded-lg font-semibold text-sm transition-all duration-150"
            style={{
              color: current === 0 ? "#b0c8d4" : TEAL,
              background: current === 0 ? "transparent" : "rgba(3,98,85,0.06)",
              cursor: current === 0 ? "not-allowed" : "pointer",
            }}
          >
            <ChevronLeft size={16} />
            Previous
          </button>

          {/* Dot indicators */}
          <div className="flex items-center gap-2">
            {slides.map((_, i) => (
              <button
                key={i}
                onClick={() => go(i)}
                style={{
                  width: i === current ? "24px" : "8px",
                  height: "8px",
                  borderRadius: "4px",
                  background: i === current ? slide.accentColor : "rgba(3,98,85,0.2)",
                  transition: "all 0.25s ease",
                  border: "none",
                  padding: 0,
                  cursor: "pointer",
                }}
              />
            ))}
          </div>

          <button
            onClick={() => go(current + 1)}
            disabled={current === slides.length - 1}
            className="flex items-center gap-1 px-4 py-2 rounded-lg font-semibold text-sm transition-all duration-150"
            style={{
              color: current === slides.length - 1 ? "#b0c8d4" : "#ffffff",
              background: current === slides.length - 1 ? "transparent" : slide.accentColor,
              cursor: current === slides.length - 1 ? "not-allowed" : "pointer",
            }}
          >
            Next
            <ChevronRight size={16} />
          </button>
        </div>
      </div>

      {/* Slide counter */}
      <p
        className="mt-4 text-sm font-semibold"
        style={{ color: TEAL, letterSpacing: "0.06em", fontFamily: "'Nunito Sans', sans-serif" }}
      >
        {current + 1} / {slides.length}
      </p>
    </div>
  );
}

function SlideContent({ slide }: { slide: Slide }) {
  if (slide.type === "title") {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center gap-6">
        {/* Decorative icon cluster */}
        <div className="flex gap-4 mb-2">
          {[Eye, Headphones, BookOpen, Zap].map((Icon, i) => (
            <div
              key={i}
              className="flex items-center justify-center rounded-full"
              style={{
                width: 52,
                height: 52,
                background: [BLUE, GREEN, TEAL, BLUE][i] + "18",
                color: [BLUE, GREEN, TEAL, BLUE][i],
              }}
            >
              <Icon size={24} strokeWidth={1.5} />
            </div>
          ))}
        </div>
        <div>
          <h1
            className="font-extrabold leading-tight mb-3"
            style={{ fontSize: "2.2rem", color: TEAL, fontFamily: "'Nunito', sans-serif" }}
          >
            {slide.title}
          </h1>
          <p
            className="font-semibold uppercase tracking-widest text-sm"
            style={{ color: BLUE, fontFamily: "'Nunito Sans', sans-serif" }}
          >
            {slide.subtitle}
          </p>
        </div>
        <div
          style={{
            width: 64,
            height: 3,
            background: `linear-gradient(90deg, ${TEAL}, ${GREEN})`,
            borderRadius: 2,
          }}
        />
      </div>
    );
  }

  if (slide.type === "intro") {
    return (
      <div className="flex flex-col justify-center h-full gap-6">
        <div>
          <div
            className="text-xs font-bold uppercase tracking-widest mb-3"
            style={{ color: BLUE, fontFamily: "'Nunito Sans', sans-serif" }}
          >
            Overview
          </div>
          <h2
            className="font-extrabold leading-snug mb-5"
            style={{ fontSize: "1.75rem", color: TEAL, fontFamily: "'Nunito', sans-serif" }}
          >
            {slide.title}
          </h2>
        </div>
        <p
          className="leading-relaxed"
          style={{ color: "#1a3a36", fontSize: "1.05rem", fontFamily: "'Nunito Sans', sans-serif" }}
        >
          {slide.body}
        </p>
        {/* Four style pills */}
        <div className="flex flex-wrap gap-3 mt-2">
          {["Visual", "Auditory", "Reading/Writing", "Kinesthetic"].map((s, i) => (
            <span
              key={s}
              className="px-4 py-1.5 rounded-full text-sm font-bold"
              style={{
                background: [BLUE, GREEN, TEAL, BLUE][i] + "18",
                color: [BLUE, GREEN, TEAL, BLUE][i],
                fontFamily: "'Nunito', sans-serif",
              }}
            >
              {s}
            </span>
          ))}
        </div>
      </div>
    );
  }

  if (slide.type === "learner") {
    return (
      <div className="flex flex-col justify-center h-full gap-5">
        {/* Header row */}
        <div className="flex items-center gap-4">
          <div
            className="flex items-center justify-center rounded-2xl flex-shrink-0"
            style={{
              width: 64,
              height: 64,
              background: slide.accentColor + "15",
              color: slide.accentColor,
            }}
          >
            {slide.icon}
          </div>
          <div>
            <div
              className="text-xs font-bold uppercase tracking-widest mb-1"
              style={{ color: slide.accentColor, fontFamily: "'Nunito Sans', sans-serif" }}
            >
              Learning Style
            </div>
            <h2
              className="font-extrabold leading-tight"
              style={{ fontSize: "1.75rem", color: TEAL, fontFamily: "'Nunito', sans-serif" }}
            >
              {slide.title}
            </h2>
          </div>
        </div>
        {/* Divider */}
        <div style={{ height: 1, background: slide.accentColor + "22" }} />
        {/* Body */}
        <p
          className="leading-relaxed"
          style={{ color: "#1a3a36", fontSize: "1rem", fontFamily: "'Nunito Sans', sans-serif" }}
        >
          {slide.body}
        </p>
      </div>
    );
  }

  if (slide.type === "strategies") {
    return (
      <div className="flex flex-col justify-center h-full gap-4">
        <div>
          <div
            className="text-xs font-bold uppercase tracking-widest mb-2"
            style={{ color: slide.accentColor, fontFamily: "'Nunito Sans', sans-serif" }}
          >
            Strategies
          </div>
          <h2
            className="font-extrabold leading-tight mb-1"
            style={{ fontSize: "1.6rem", color: TEAL, fontFamily: "'Nunito', sans-serif" }}
          >
            {slide.title}
          </h2>
          {slide.subtitle && (
            <p
              className="text-sm leading-relaxed mb-3"
              style={{ color: "#3a5a56", fontFamily: "'Nunito Sans', sans-serif" }}
            >
              {slide.subtitle}
            </p>
          )}
        </div>
        <div className="flex flex-col gap-3">
          {slide.items?.map((item) => (
            <div
              key={item.label}
              className="flex gap-4 rounded-xl p-4"
              style={{ background: slide.accentColor + "0d", border: `1px solid ${slide.accentColor}20` }}
            >
              <div
                className="flex-shrink-0 flex items-center justify-center rounded-lg mt-0.5"
                style={{ width: 36, height: 36, background: slide.accentColor + "18", color: slide.accentColor }}
              >
                {strategyIcons[item.label] ?? null}
              </div>
              <div>
                <div
                  className="font-bold mb-1 text-sm"
                  style={{ color: slide.accentColor, fontFamily: "'Nunito', sans-serif" }}
                >
                  {item.label}
                </div>
                <p
                  className="text-sm leading-relaxed"
                  style={{ color: "#1a3a36", fontFamily: "'Nunito Sans', sans-serif" }}
                >
                  {item.text}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (slide.type === "closing") {
    return (
      <div className="flex flex-col items-center justify-center h-full text-center gap-6">
        <div
          className="flex items-center justify-center rounded-full"
          style={{
            width: 72,
            height: 72,
            background: `linear-gradient(135deg, ${TEAL}22, ${BLUE}22)`,
          }}
        >
          <BookMarked size={32} strokeWidth={1.5} style={{ color: TEAL }} />
        </div>
        <div>
          <h2
            className="font-extrabold leading-tight mb-5"
            style={{ fontSize: "1.9rem", color: TEAL, fontFamily: "'Nunito', sans-serif" }}
          >
            {slide.title}
          </h2>
          <p
            className="leading-relaxed max-w-xl mx-auto"
            style={{ color: "#1a3a36", fontSize: "1.05rem", fontFamily: "'Nunito Sans', sans-serif" }}
          >
            {slide.body}
          </p>
        </div>
        <div className="flex gap-2 mt-2">
          {[TEAL, BLUE, GREEN].map((c) => (
            <div key={c} style={{ width: 10, height: 10, borderRadius: "50%", background: c }} />
          ))}
        </div>
      </div>
    );
  }

  return null;
}
